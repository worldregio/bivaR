# =================================
# Exercice 1 : Premiers pas dans R
# ================================

# ---- opérations élémentaires --------------

8+2

8-2

8*2

8/2

8**2

8**(1/2)

log(10)

log10(10)

sqrt(10)

sin(pi)

cos(pi)

tan(pi)


# ---- objets élémentaires----------------------------

# Numérique
x<-8
y<-2

x+y
x*y
x**y



# caractère
x<-"Bonjour"
y<- "tout le monde"
z<- "!"
paste(x,y,z)
substr(x,1,3)


# logique
y<-FALSE

x & y
x | y 


# -----   vecteurs---------------
x <- c(1,2,4,8,16)
y <- 4
x+y
x*y
x**y


# ----- matrices-----------------

# deux vecteurs
x1 <- c(1,2,4,8,16)
x2 <- c(5,10,15,20,25)

# matrice en colonnes
m1 <- cbind(x1,x2)
m1

# matrice en lignes
m2 <- rbind(x1,x2)
m2

# piège !
m3 <- c(x1,x2)
m3
is.matrix(m3)




# ----listes et vecteurs --------------

# Format vecteur
prenom <- c("Ali", "Amine",
    "Anne","Marc","Zayneb")
sexe <- c("H","H","F","H","F")
age  <- c(21,22,24,18,25)


# Format liste
Ali <- list("H",21)
Amine <- list("F",22)
Anne <- list("F",28)
Marc <- list ("H",18)
Zayneb <- list("F",25)

# Ne pas confondre !
Ali <- c("H",21)
Ali
Ali <- list("H",21)
Ali


# ----types de variables ---------------

# Format charactère
prenom <- c("Ali", "Amine","Anne",
            "Marc","Zayneb")
str(prenom)

# Format logique
likeR <- c(TRUE,FALSE, TRUE,
           FALSE, FALSE)
str(likeR)
# Format Factor
sexe <- c(1,1,2,1,2)
sexe<-as.factor(sexe)
levels(sexe) <-c("Homme","Femme")
str(sexe)

# Format numerique
age  <- c(21,22,24,18,25)
str(age)

# Format date
nais<-c("1999-10-28","1998-10-13",
 "1996-10-15","2002-02-07","1995-06-18")
nais<-as.Date(nais)
str(nais)


# ----types de tableaux --------------------------

# Création d'un data.frame
tab1<-data.frame(prenom,nais,
                age,sexe,likeR)
str(tab1)


# Création d'un tibble
library(tidyr, quiet=T)
tab2<-tibble(prenom,nais,
            age,sexe,likeR)
str(tab2)


# Création d'un data.table
library(data.table, quiet=T)
tab3<-data.table(prenom,nais,
                age,sexe,likeR)
str(tab3)



# ----exo1 ------------------------------------

x <- c("Paris", "Londres","Tokyo","New York")
x

y <- c("France", "Royaume-Uni","Japon","USA")
y


z <- c(10.2, 14.6,42.8,23.9)
z

m1<-rbind(x,y)
m1

df<-data.frame(y,x,z)
df




# ---- Exo 2 (d'après J. Barnier) -------------------

 conjoint1 <- c(1200, 1180, 1750, 2100)
 conjoint2 <- c(1450, 1870, 1690, 0)
 nb_personnes <- c(4, 2, 3, 2)
 revenu_total <- conjoint1 + conjoint2
 revenu_total / nb_personnes

