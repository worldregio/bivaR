## PROGRAMME EXCEL KILLER

# Round 1 : Importation du tableau de données



# Round 2. Inventaire des sports disponible



# Round 3. Sélection d'un sport et d'une période



# Round 4. Analyse de l'âge, du poids, de la taille et de l'IMC des sportifs



# Round 5 : Nombre de médailles d'or par pays et par épreuve 



# Roud  6 : Refaire toute l'analyse en changeant de sport et de période




