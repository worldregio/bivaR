## PROGRAMME EXCEL KILLER

# (1) Importation du tableau
don <- read.table(file = "resources/data/olympic/120-years-of-olympic-history-athletes-and-results.csv",
                  header= TRUE,
                  sep =",")

# (2) Inventaire des sports disponibles
table(don$Sport)

# (3) Sélection du sport et de la date
sel <- don[don$Year > 1990 & don$Sport=="Judo" & is.na(don$Medal)==FALSE,]

# (4) Caractéristiques des sportifs
tapply(sel$Age, 
       INDEX = sel$Sex,
       FUN="summary")

tapply(sel$Height, 
       INDEX = sel$Sex,
       FUN="summary")

tapply(sel$Weight,
       INDEX=sel$Sex,
       FUN="summary")

sel$IMC <- sel$Weight/(sel$Height/100)**2

tapply(sel$IMC,
       INDEX=sel$Sex,
       FUN="summary")

# (5) Médailles d'or par pays et épreuve

# Sélection des lignes  (médailles d'or)
sel2 <- sel[sel$Medal=="Gold",]

# Selection des colonnes 
sel3 <- sel2[,c("NOC","Year","Event")]

# Elimination des doublons
sel4 <-unique(sel3)

# Tableau croisé
tab<-table(sel4$Event,sel4$NOC)

# Ajout des marges
addmargins(tab)